Star Fighter
Release version: 1.0.0
Author: zyenapz
E-mail: zyenapz@gmail.com

Hello, thank you very much for downloading Star Fighter! I hope you enjoy playing the game!
The controls in-game are:
	
	WASD - movement controls
	Space - fire laser
	Esc - pause the game

Special thanks to these people!
	Font: Press Start by codeman38
	Music: 'Fighter' by YoItsRion

