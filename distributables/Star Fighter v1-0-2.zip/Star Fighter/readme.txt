Star Fighter
Release version: 1.0.2
Author: zyenapz
E-mail: zyenapz@gmail.com
Website: zyenapz.github.io

Hello, thank you very much for downloading Star Fighter! I hope you enjoy playing the game!
The controls in-game are:
	
	WASD - movement controls
	Space - fire laser
	Esc or P - pause the game

Special thanks to these people!
	Font: 'Press Start' by codeman38
	Music: 'Star Fighter' by YoItsRion

-----------------------------------
Update 1.0.2
- Code refactoring
	- Made the main file more readable by adding comments
	- Added "colors" parameter to Particle class
	- Changed fonts and scores string paths to os module paths
- Added my personal best (253). Try to beat it >:D

Update 1.0.1
- Now able to pause with 'P' and 'ESC'
- Changed upgrade's types chances of spawning
- Changed monster's chances of spawning
- Hid mouse cursor